package com.uply
import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var h = 6; private var m = 0; private var reps = 10
    private lateinit var time: TextView; private lateinit var repsTv: TextView; private lateinit var toggle: Button

    private val names = listOf("P" to "💪 ضغط", "F" to "😊 وجه", "O" to "📷 تصوير")
    private val mBtns = mutableListOf<Button>()
    private fun tv(t: String, sz: Float, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); gravity = Gravity.CENTER }
    private fun btn(t: String, bg: Int, f: () -> Unit) = Button(this).apply { text = t; setTextColor(Color.WHITE); setBackgroundColor(bg); setOnClickListener { f() } }
    private fun refresh() {
        val sel = Scheduler.missions(this)
        mBtns.forEachIndexed { i, bt -> bt.setBackgroundColor(if (names[i].first in sel) 0xFFFF6A1A.toInt() else 0xFF333333.toInt()) }
        time.text = "%02d:%02d".format(h, m); repsTv.text = "$reps"
        toggle.text = if (Scheduler.enabled(this)) "إيقاف المنبه" else "تفعيل المنبه"
        toggle.setBackgroundColor(if (Scheduler.enabled(this)) 0xFF444444.toInt() else 0xFFFF6A1A.toInt())
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS), 1)
        if (android.os.Build.VERSION.SDK_INT >= 34 && !getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, android.net.Uri.parse("package:$packageName")))
        Scheduler.load(this).let { h = it.first; m = it.second; reps = it.third }
        time = tv("", 72f).apply { setOnClickListener { TimePickerDialog(this@MainActivity, { _, a, c -> h = a; m = c; refresh() }, h, m, false).show() } }
        repsTv = tv("", 48f, 0xFFFF6A1A.toInt())
        toggle = btn("", 0) { if (Scheduler.enabled(this)) Scheduler.cancel(this) else Scheduler.set(this, h, m, reps); refresh() }
        val mRow = LinearLayout(this).apply { gravity = Gravity.CENTER
            names.forEach { (k, l) -> val b = btn(l, 0) {
                val cur = Scheduler.missions(this@MainActivity).toMutableList()
                if (k in cur) { if (cur.size > 1) cur.remove(k) } else cur.add(k)
                Scheduler.setMissions(this@MainActivity, names.map { it.first }.filter { it in cur }); refresh() }
                mBtns.add(b); addView(b) } }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER
            addView(btn("–", 0xFF333333.toInt()) { if (reps > 1) reps--; refresh() })
            addView(repsTv, LinearLayout.LayoutParams(300, -2))
            addView(btn("+", 0xFF333333.toInt()) { reps++; refresh() }) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0E0E12.toInt()); setPadding(48, 160, 48, 48)
            addView(tv("UPLY", 22f, 0xFFFF6A1A.toInt())); addView(tv("اضغط على الوقت لتغييره", 13f, Color.GRAY)); addView(time)
            addView(tv("\nالمهام (اختر وحدة أو أكثر)", 16f, Color.GRAY)); addView(mRow); addView(tv("\nعدد الضغطات", 16f, Color.GRAY)); addView(row)
            addView(tv("", 20f)); addView(toggle)
            addView(btn("جرّب الآن (بدون منبه)", 0xFF222222.toInt()) { startActivity(Intent(this@MainActivity, AlarmActivity::class.java).putExtra("reps", reps)) })
        })
        refresh()
    }
}
