package com.uply
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.IBinder

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val reps = i?.getIntExtra("reps", 5) ?: 5
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alarm", "Alarm", NotificationManager.IMPORTANCE_HIGH))
        val open = Intent(this, AlarmActivity::class.java).putExtra("reps", reps).putExtra("m", Scheduler.missions(this).joinToString(",")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Uply").setContentText("اضغط لبدء تمارين الضغط 💪").setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(pi).setFullScreenIntent(pi, true).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        if (player == null) player = MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI).apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()); isLooping = true; start()
        }
        try { startActivity(open) } catch (e: Exception) {}
        return START_STICKY
    }
    override fun onDestroy() { player?.release(); super.onDestroy() }
}
