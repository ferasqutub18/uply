package com.uply
import android.graphics.Color
import android.os.*
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.*
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.pose.*
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlin.math.abs
import kotlin.math.atan2

class AlarmActivity : AppCompatActivity() {
    private lateinit var counter: TextView; private lateinit var hint: TextView; private lateinit var preview: PreviewView
    private lateinit var missions: List<String>
    private var idx = 0; private var target = 5; private var count = 0; private var down = false
    private var holdStart = 0L; private var lo = 9.0; private var hi = -9.0
    private var goal = "" ; private var goalWords = listOf<String>()
    private var run: (InputImage) -> Task<*> = { throw IllegalStateException() }
    private val poseDet by lazy { PoseDetection.getClient(PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build()) }
    private val faceDet by lazy { FaceDetection.getClient(FaceDetectorOptions.Builder().setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build()) }
    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build()) }
    private val goals = listOf("Couch" to listOf("couch", "sofa"), "Refrigerator" to listOf("refrigerator", "fridge"), "Kitchen" to listOf("kitchen"),
        "Sink" to listOf("sink"), "Bed" to listOf("bed"), "Chair" to listOf("chair"), "Window" to listOf("window"), "Cup" to listOf("cup", "mug", "drinkware"))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        target = intent.getIntExtra("reps", 5)
        missions = (intent.getStringExtra("m") ?: Scheduler.missions(this).joinToString(",")).split(",")
        preview = PreviewView(this)
        counter = TextView(this).apply { textSize = 56f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        hint = TextView(this).apply { textSize = 20f; setTextColor(Color.WHITE); setBackgroundColor(0x99000000.toInt()); gravity = Gravity.CENTER; setPadding(32, 24, 32, 24) }
        setContentView(FrameLayout(this).apply {
            addView(preview, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(counter, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP).apply { topMargin = 150 })
            addView(hint, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER).apply { bottomMargin = 200 })
        })
        startMission()
    }

    private fun startMission() {
        if (idx >= missions.size) { stopService(android.content.Intent(this, AlarmService::class.java)); finish(); return }
        count = 0; down = false; holdStart = 0; lo = 9.0; hi = -9.0
        val front = when (missions[idx]) {
            "P" -> { counter.text = "0/$target"; hint.text = "Get in push-up position"; run = { i -> poseDet.process(i).addOnSuccessListener { onPose(it) } }; true }
            "F" -> { counter.text = "😊"; hint.text = "Open your eyes and smile"; run = { i -> faceDet.process(i).addOnSuccessListener { onFaces(it) } }; true }
            else -> { val g = goals.random(); goal = g.first; goalWords = g.second; counter.text = "📷"; hint.text = "Find: $goal"
                run = { i -> labeler.process(i).addOnSuccessListener { ls -> if (ls.any { l -> goalWords.any { it in l.text.lowercase() } }) done() } }; false }
        }
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { px ->
                val img = px.image ?: return@setAnalyzer px.close()
                run(InputImage.fromMediaImage(img, px.imageInfo.rotationDegrees)).addOnCompleteListener { px.close() }
            }
            fut.get().apply {
                unbindAll()
                bindToLifecycle(this@AlarmActivity, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                    Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }, analysis)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun done() {
        if (idx >= missions.size) return
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(300, 255))
        idx++; run = { throw IllegalStateException() }; startMission()
    }

    private fun onFaces(fs: List<Face>) {
        val f = fs.firstOrNull()
        val ok = f != null && (f.leftEyeOpenProbability ?: 0f) > 0.7f && (f.rightEyeOpenProbability ?: 0f) > 0.7f && (f.smilingProbability ?: 0f) > 0.6f
        if (!ok) { holdStart = 0; hint.text = "Open your eyes and smile"; return }
        if (holdStart == 0L) holdStart = System.currentTimeMillis()
        val left = 3 - (System.currentTimeMillis() - holdStart) / 1000
        hint.text = "Hold it... $left"
        if (left <= 0) done()
    }

    private fun angle(a: PoseLandmark, m: PoseLandmark, c: PoseLandmark): Double {
        val d = abs(Math.toDegrees((atan2(c.position.y - m.position.y, c.position.x - m.position.x) -
                atan2(a.position.y - m.position.y, a.position.x - m.position.x)).toDouble()))
        return if (d > 180) 360 - d else d
    }

    private fun rep() {
        down = false; count++; counter.text = "$count/$target"; hint.text = "Lower your chest"
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(80, 255))
        if (count >= target) done()
    }

    private fun onPose(p: Pose) {
        val l = listOf(PoseLandmark.LEFT_SHOULDER, PoseLandmark.LEFT_ELBOW, PoseLandmark.LEFT_WRIST).map { p.getPoseLandmark(it) }
        val r = listOf(PoseLandmark.RIGHT_SHOULDER, PoseLandmark.RIGHT_ELBOW, PoseLandmark.RIGHT_WRIST).map { p.getPoseLandmark(it) }
        val side = listOf(l, r).firstOrNull { s -> s.all { it != null && it.inFrameLikelihood > 0.6f } }
        if (side != null) {
            val a = angle(side[0]!!, side[1]!!, side[2]!!)
            if (a < 90 && !down) { down = true; hint.text = "Push back up" } else if (a > 155 && down) rep()
            return
        }
        val n = p.getPoseLandmark(PoseLandmark.NOSE) ?: return
        val ls = p.getPoseLandmark(PoseLandmark.LEFT_SHOULDER) ?: return
        val rs = p.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER) ?: return
        val sw = abs(ls.position.x - rs.position.x).toDouble().coerceAtLeast(1.0)
        val v = (n.position.y - (ls.position.y + rs.position.y) / 2) / sw
        hi = maxOf(v, hi - 0.003); lo = minOf(v, lo + 0.003)
        val range = hi - lo; if (range < 0.3) return
        if (v > lo + 0.7 * range && !down) { down = true; hint.text = "Push back up" } else if (v < lo + 0.3 * range && down) rep()
    }

    @Deprecated("") override fun onBackPressed() {}
}
