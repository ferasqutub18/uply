package com.uply
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*

class AlarmService : Service() {
    private var track: AudioTrack? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val reps = i?.getIntExtra("reps", 5) ?: 5
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alarm", "Alarm", NotificationManager.IMPORTANCE_HIGH))
        val open = Intent(this, AlarmActivity::class.java).putExtra("reps", reps).putExtra("m", Scheduler.missions(this).joinToString(",")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("صاحي ⏰").setContentText("اضغط لبدء مهام الاستيقاظ").setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(pi).setFullScreenIntent(pi, true).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        if (track == null) { track = Tone.track(Scheduler.sound(this)); track?.play() }
        try { getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 250, 500, 250, 500, 900), 0)) } catch (e: Exception) {}
        try { startActivity(open) } catch (e: Exception) {}
        return START_STICKY
    }
    override fun onDestroy() {
        try { track?.stop(); track?.release() } catch (e: Exception) {}
        try { getSystemService(Vibrator::class.java)?.cancel() } catch (e: Exception) {}
        super.onDestroy()
    }
}
