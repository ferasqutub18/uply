package com.uply
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.*
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.*
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.pose.*
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import kotlin.math.sqrt

class Overlay(c: Context) : View(c) {
    var segs = listOf<Pair<PointF, PointF>>(); var dots = listOf<PointF>(); var box: RectF? = null; var good = true
    var iw = 1f; var ih = 1f; var mirror = true
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E676.toInt(); strokeWidth = 8f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E676.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f }
    private fun map(p: PointF): PointF {
        val s = maxOf(width / iw, height / ih)
        val x = p.x * s + (width - iw * s) / 2; val y = p.y * s + (height - ih * s) / 2
        return PointF(if (mirror) width - x else x, y)
    }
    override fun onDraw(c: Canvas) {
        segs.forEach { val a = map(it.first); val b = map(it.second); c.drawLine(a.x, a.y, b.x, b.y, line) }
        dots.forEach { val p = map(it); c.drawCircle(p.x, p.y, 12f, dot); c.drawCircle(p.x, p.y, 19f, ring) }
        box?.let {
            val a = map(PointF(it.left, it.top)); val b = map(PointF(it.right, it.bottom))
            line.color = if (good) 0xFF00E676.toInt() else 0xFFFF6A1A.toInt()
            c.drawRoundRect(minOf(a.x, b.x), a.y, maxOf(a.x, b.x), b.y, 28f, 28f, line); line.color = 0xFF00E676.toInt()
        }
    }
}

class AlarmActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView; private lateinit var ov: Overlay
    private lateinit var titleTv: TextView; private lateinit var counter: TextView; private lateinit var step: TextView; private lateinit var hintTv: TextView
    private lateinit var mathBox: LinearLayout; private lateinit var mathQ: TextView; private lateinit var mathIn: EditText
    private lateinit var missions: List<String>
    private var idx = 0; private var target = 10; private var count = 0; private var down = false
    private var hi = -1e9; private var lo = 1e9; private var holdStart = 0L; private var imgH = 1; private var ans = 0; private var lastShake = 0L
    private var analyzer: (InputImage) -> Task<*> = { throw IllegalStateException() }
    private val poseDet by lazy { PoseDetection.getClient(AccuratePoseDetectorOptions.Builder().setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE).build()) }
    private val faceDet by lazy { FaceDetection.getClient(FaceDetectorOptions.Builder().setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build()) }
    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build()) }
    private var goalWords = listOf<String>()
    private val goals = listOf("كنبة" to listOf("couch", "sofa"), "ثلاجة" to listOf("refrigerator", "fridge"), "مطبخ" to listOf("kitchen"), "حوض" to listOf("sink"),
        "سرير" to listOf("bed"), "كرسي" to listOf("chair"), "نافذة" to listOf("window"), "كوب" to listOf("cup", "mug", "drinkware"),
        "تلفزيون" to listOf("television"), "نبتة" to listOf("plant", "houseplant"))
    private val bones = listOf(PoseLandmark.LEFT_SHOULDER to PoseLandmark.RIGHT_SHOULDER, PoseLandmark.LEFT_SHOULDER to PoseLandmark.LEFT_ELBOW,
        PoseLandmark.LEFT_ELBOW to PoseLandmark.LEFT_WRIST, PoseLandmark.RIGHT_SHOULDER to PoseLandmark.RIGHT_ELBOW, PoseLandmark.RIGHT_ELBOW to PoseLandmark.RIGHT_WRIST,
        PoseLandmark.LEFT_SHOULDER to PoseLandmark.LEFT_HIP, PoseLandmark.RIGHT_SHOULDER to PoseLandmark.RIGHT_HIP, PoseLandmark.LEFT_HIP to PoseLandmark.RIGHT_HIP,
        PoseLandmark.LEFT_HIP to PoseLandmark.LEFT_KNEE, PoseLandmark.LEFT_KNEE to PoseLandmark.LEFT_ANKLE,
        PoseLandmark.RIGHT_HIP to PoseLandmark.RIGHT_KNEE, PoseLandmark.RIGHT_KNEE to PoseLandmark.RIGHT_ANKLE)
    private val joints = listOf(PoseLandmark.NOSE, PoseLandmark.LEFT_SHOULDER, PoseLandmark.RIGHT_SHOULDER, PoseLandmark.LEFT_ELBOW, PoseLandmark.RIGHT_ELBOW,
        PoseLandmark.LEFT_WRIST, PoseLandmark.RIGHT_WRIST, PoseLandmark.LEFT_HIP, PoseLandmark.RIGHT_HIP, PoseLandmark.LEFT_KNEE, PoseLandmark.RIGHT_KNEE)
    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / 9.81f
            val now = System.currentTimeMillis()
            if (g > 2.2f && now - lastShake > 300) { lastShake = now; count++; counter.text = "$count/30"; vib(60); if (count >= 30) done() }
        }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun box(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(22).toFloat() }
    private fun vib(ms: Long) { try { getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (e: Exception) {} }
    private fun t(sz: Float, bold: Boolean = false) = TextView(this).apply { textSize = sz; setTextColor(Color.WHITE); gravity = Gravity.CENTER; if (bold) typeface = Typeface.DEFAULT_BOLD }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        target = intent.getIntExtra("reps", 10)
        missions = (intent.getStringExtra("m") ?: Scheduler.missions(this).joinToString(",")).split(",")
        preview = PreviewView(this); ov = Overlay(this)
        titleTv = t(22f, true); counter = t(54f, true); step = t(13f).apply { setTextColor(0xFFFFB48A.toInt()) }
        hintTv = t(19f).apply { background = box(0xCC000000.toInt()); setPadding(dp(20), dp(16), dp(20), dp(16)) }
        val topCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = box(0xAA000000.toInt()); setPadding(dp(24), dp(12), dp(24), dp(12))
            addView(step); addView(titleTv); addView(counter) }
        mathQ = t(40f, true).apply { textDirection = View.TEXT_DIRECTION_LTR }
        mathIn = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = box(0xFF181820.toInt()) }
        val ok = t(18f, true).apply { text = "تأكيد"; background = box(0xFFFF6A1A.toInt()); setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { val x = mathIn.text.toString().toIntOrNull()
                if (x == ans) { count++; counter.text = "$count/3"; vib(80); if (count >= 3) done() else newQ() } else { hintTv.text = "إجابة خاطئة ❌ جرّب مرة ثانية"; vib(200) } } }
        mathBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE
            addView(t(16f).apply { text = "احسب:" }); addView(mathQ); addView(mathIn, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
            addView(ok, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }) }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(0xFF0B0B10.toInt()); layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(preview, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)); addView(ov, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(topCard, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(48) })
            addView(mathBox, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER).apply { setMargins(dp(32), 0, dp(32), 0) })
            addView(hintTv, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(64); marginStart = dp(24); marginEnd = dp(24) })
        })
        startMission()
    }

    private fun newQ() { val a = (11..29).random(); val b2 = (3..9).random(); val c = (10..49).random(); ans = a * b2 + c; mathQ.text = "$a × $b2 + $c"; mathIn.setText("") }

    private fun startMission() {
        if (idx >= missions.size) { stopService(android.content.Intent(this, AlarmService::class.java)); finish(); return }
        count = 0; down = false; hi = -1e9; lo = 1e9; holdStart = 0
        ov.segs = listOf(); ov.dots = listOf(); ov.box = null; ov.invalidate(); mathBox.visibility = View.GONE
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(sensorListener)
        step.text = "المهمة ${idx + 1} من ${missions.size}"
        val id = idx; var cam = true; var front = true
        when (missions[idx]) {
            "P" -> { titleTv.text = "💪 تمارين الضغط"; counter.text = "0/$target"; hintTv.text = "حط الجوال قدامك على الأرض وخلّ جسمك يبان"
                analyzer = { i -> poseDet.process(i).addOnSuccessListener { if (id == idx) onPose(it) } } }
            "Q" -> { titleTv.text = "🏋️ قرفصاء"; counter.text = "0/$target"; hintTv.text = "وقّف الجوال بحيث أشوف جسمك كامل"
                analyzer = { i -> poseDet.process(i).addOnSuccessListener { if (id == idx) onPose(it) } } }
            "F" -> { titleTv.text = "😊 فحص الوجه"; counter.text = "😊"; hintTv.text = "افتح عيونك وابتسم"
                analyzer = { i -> faceDet.process(i).addOnSuccessListener { if (id == idx) onFaces(it) } } }
            "O" -> { val g = goals.random(); goalWords = g.second; front = false; titleTv.text = "📷 صوّر: ${g.first}"; counter.text = "📷"; hintTv.text = "وجّه الكاميرا الخلفية على ${g.first}"
                analyzer = { i -> labeler.process(i).addOnSuccessListener { ls -> if (id == idx) {
                    if (ls.any { l -> goalWords.any { it in l.text.lowercase() } }) done() else { hintTv.text = "أشوف: ${ls.firstOrNull()?.text ?: "—"}  |  المطلوب: ${g.first}" } } } } }
            "M" -> { cam = false; titleTv.text = "🧮 حل المسائل"; counter.text = "0/3"; hintTv.text = "حل 3 مسائل"; mathBox.visibility = View.VISIBLE; newQ() }
            else -> { cam = false; titleTv.text = "📳 هز الجوال"; counter.text = "0/30"; hintTv.text = "هز الجوال بقوة 30 مرة"
                val sm = getSystemService(SENSOR_SERVICE) as SensorManager
                sm.registerListener(sensorListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME) }
        }
        preview.visibility = if (cam) View.VISIBLE else View.GONE
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val prov = fut.get(); prov.unbindAll()
            if (!cam) return@addListener
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { px ->
                val img = px.image
                if (img == null) { px.close(); return@setAnalyzer }
                val rot = px.imageInfo.rotationDegrees
                ov.iw = (if (rot % 180 == 0) px.width else px.height).toFloat(); ov.ih = (if (rot % 180 == 0) px.height else px.width).toFloat()
                imgH = ov.ih.toInt(); ov.mirror = front
                analyzer(InputImage.fromMediaImage(img, rot)).addOnCompleteListener { px.close() }
            }
            prov.bindToLifecycle(this, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun done() { vib(300); idx++; analyzer = { throw IllegalStateException() }; startMission() }

    private fun rep() { down = false; count++; counter.text = "$count/$target"; hintTv.text = "ممتاز! كمّل 🔥"; vib(80); if (count >= target) done() }

    private fun cycle(v: Double, minRange: Double): Boolean {
        hi = maxOf(v, hi - minRange * 0.005); lo = minOf(v, lo + minRange * 0.005)
        val r = hi - lo; if (r < minRange) return false
        if (v > lo + 0.65 * r && !down) { down = true; return false }
        if (v < lo + 0.35 * r && down) { down = false; return true }
        return false
    }

    private fun onPose(p: Pose) {
        ov.segs = bones.mapNotNull { (a, b) -> val la = p.getPoseLandmark(a); val lb = p.getPoseLandmark(b)
            if (la != null && lb != null && la.inFrameLikelihood > 0.5f && lb.inFrameLikelihood > 0.5f) Pair(la.position, lb.position) else null }
        ov.dots = joints.mapNotNull { j -> p.getPoseLandmark(j)?.takeIf { it.inFrameLikelihood > 0.5f }?.position }
        ov.invalidate()
        val cur = missions[idx]
        val v: Double? = if (cur == "P") p.getPoseLandmark(PoseLandmark.NOSE)?.takeIf { it.inFrameLikelihood > 0.5f }?.position?.y?.toDouble()
        else { val a = p.getPoseLandmark(PoseLandmark.LEFT_HIP); val b2 = p.getPoseLandmark(PoseLandmark.RIGHT_HIP)
            if (a != null && b2 != null && a.inFrameLikelihood > 0.5f && b2.inFrameLikelihood > 0.5f) ((a.position.y + b2.position.y) / 2).toDouble() else null }
        if (v == null) { hintTv.text = "ما أشوفك 👀 ثبّت الجوال وخلّ جسمك داخل الشاشة"; return }
        if (cycle(v, (if (cur == "P") 0.06 else 0.08) * imgH)) rep() else hintTv.text = if (down) "اطلع فوق ⬆️" else "انزل ⬇️"
    }

    private fun onFaces(fs: List<Face>) {
        val f = fs.firstOrNull()
        val ok = f != null && (f.leftEyeOpenProbability ?: 0f) > 0.7f && (f.rightEyeOpenProbability ?: 0f) > 0.7f && (f.smilingProbability ?: 0f) > 0.6f
        ov.box = f?.boundingBox?.let { RectF(it) }; ov.good = ok; ov.invalidate()
        if (!ok) { holdStart = 0; hintTv.text = if (f == null) "ما أشوف وجهك 👀" else "افتح عيونك وابتسم 😄"; return }
        if (holdStart == 0L) holdStart = System.currentTimeMillis()
        val left = 3 - (System.currentTimeMillis() - holdStart) / 1000
        hintTv.text = "ثبّت كذا... $left"; counter.text = "$left"
        if (left <= 0) done()
    }

    override fun onDestroy() { (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(sensorListener); super.onDestroy() }
    @Deprecated("") override fun onBackPressed() {}
}
