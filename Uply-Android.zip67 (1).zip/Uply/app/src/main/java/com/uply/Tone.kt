package com.uply
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

object Tone {
    private const val SR = 44100
    private fun build(segs: List<Triple<Double, Double, Double>>): ShortArray {
        val total = segs.sumOf { (it.first * SR).toInt() }
        val out = ShortArray(total); var i = 0; var phase = 0.0
        for ((d, f0, f1) in segs) {
            val n = (d * SR).toInt()
            for (k in 0 until n) {
                val f = f0 + (f1 - f0) * k / n
                if (f <= 0) { out[i++] = 0; continue }
                phase += 2 * Math.PI * f / SR
                val env = minOf(1.0, minOf(k, n - k) / (0.005 * SR))
                out[i++] = ((if (Math.sin(phase) >= 0) 1.0 else -1.0) * env * 0.92 * 32767).toInt().toShort()
            }
        }
        return out
    }
    private fun pcm(style: Int): ShortArray {
        val s = mutableListOf<Triple<Double, Double, Double>>()
        when (style) {
            0 -> { repeat(3) { s.add(Triple(0.15, 2400.0, 2400.0)); s.add(Triple(0.1, 0.0, 0.0)) }; s.add(Triple(0.7, 0.0, 0.0)) }
            1 -> { s.add(Triple(0.7, 700.0, 1900.0)); s.add(Triple(0.7, 1900.0, 700.0)) }
            else -> { repeat(4) { s.add(Triple(0.08, 3000.0, 3000.0)); s.add(Triple(0.08, 0.0, 0.0)) }; s.add(Triple(0.3, 0.0, 0.0)) }
        }
        return build(s)
    }
    fun track(style: Int): AudioTrack {
        val p = pcm(style)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(p.size * 2).build()
        t.write(p, 0, p.size); t.setLoopPoints(0, p.size, -1); t.setVolume(1f)
        return t
    }
}
