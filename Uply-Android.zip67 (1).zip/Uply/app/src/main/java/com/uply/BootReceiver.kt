package com.uply
import android.content.*
class BootReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = Scheduler.reschedule(c) }
