package com.uply
import android.content.*

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        ctx.startForegroundService(Intent(ctx, AlarmService::class.java).putExtra("reps", i.getIntExtra("reps", 5)))
        Scheduler.reschedule(ctx) // يتكرر يومياً
    }
}
