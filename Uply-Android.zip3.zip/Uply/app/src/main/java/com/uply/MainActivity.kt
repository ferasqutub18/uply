package com.uply
import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {
    private val OR = 0xFFFF6A1A.toInt(); private val PINK = 0xFFFF3D6E.toInt(); private val CARD = 0xFF181820.toInt(); private val GRAY = 0xFF9A9AA8.toInt()
    private data class Mi(val k: String, val e: String, val n: String, val d: String)
    private val missionList = listOf(Mi("P", "💪", "تمارين الضغط", "عدّ تلقائي بالكاميرا"), Mi("Q", "🏋️", "قرفصاء", "قدام الكاميرا وجسمك كامل"),
        Mi("F", "😊", "فحص الوجه", "عيونك مفتوحة وابتسامة"), Mi("O", "📷", "تصوير غرض", "صوّر شي يطلبه التطبيق"),
        Mi("M", "🧮", "مسائل حساب", "حل 3 مسائل"), Mi("K", "📳", "هز الجوال", "هزّه 30 مرة"))
    private var h = 6; private var m = 0; private var reps = 10; private var updating = false
    private val switches = mutableListOf<SwitchCompat>()
    private lateinit var time: TextView; private lateinit var ampm: TextView; private lateinit var repsTv: TextView; private lateinit var toggle: TextView

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun shape(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke) }
    private fun tv(t: String, sz: Float, c: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c); gravity = Gravity.CENTER; if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun lp(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)
    private fun save() { if (Scheduler.enabled(this)) Scheduler.set(this, h, m, reps); refresh() }

    private fun refresh() {
        val sel = Scheduler.missions(this)
        updating = true; switches.forEachIndexed { i, s -> s.isChecked = missionList[i].k in sel }; updating = false
        time.text = "%d:%02d".format(if (h % 12 == 0) 12 else h % 12, m); ampm.text = if (h < 12) "صباحاً" else "مساءً"
        repsTv.text = "$reps"
        val on = Scheduler.enabled(this)
        toggle.text = if (on) "إيقاف المنبه" else "تفعيل المنبه"
        toggle.background = if (on) shape(0xFF2A2A34.toInt(), 40) else GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(OR, PINK)).apply { cornerRadius = dp(40).toFloat() }
    }

    private fun row(mi: Mi): LinearLayout {
        val icon = tv(mi.e, 22f).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x22FF6A1A) } }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
            addView(tv(mi.n, 16f, Color.WHITE, true).apply { gravity = Gravity.START }); addView(tv(mi.d, 12f, GRAY).apply { gravity = Gravity.START }) }
        val sw = SwitchCompat(this).apply {
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(OR, 0xFF8A8A96.toInt()))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(0x66FF6A1A, 0xFF33333D.toInt()))
            setOnCheckedChangeListener { _, on ->
                if (updating) return@setOnCheckedChangeListener
                val cur = Scheduler.missions(this@MainActivity).toMutableList()
                if (on) cur.add(mi.k) else cur.remove(mi.k)
                if (cur.isNotEmpty()) Scheduler.setMissions(this@MainActivity, missionList.map { it.k }.filter { it in cur.distinct() })
                refresh() } }
        switches.add(sw)
        return LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(icon, lp(dp(46), dp(46))); addView(col, lp(0, -2, 1f).apply { marginStart = dp(14) }); addView(sw)
            setOnClickListener { sw.toggle() } }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS), 1)
        if (android.os.Build.VERSION.SDK_INT >= 34 && !getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, android.net.Uri.parse("package:$packageName")))
        Scheduler.load(this).let { h = it.first; m = it.second; reps = it.third }
        val M = LinearLayout.LayoutParams.MATCH_PARENT; val W = LinearLayout.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(52), dp(22), dp(32)) }
        root.addView(tv("صاحي", 34f, OR, true).apply { gravity = Gravity.START }); root.addView(tv("ما تنام قبل ما تثبت إنك صاحي ☀️", 14f, GRAY).apply { gravity = Gravity.START })
        time = tv("", 78f, Color.WHITE, true); ampm = tv("", 18f, OR, true)
        val timeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(28), 0, dp(20))
            setOnClickListener { TimePickerDialog(this@MainActivity, { _, a, c -> h = a; m = c; save() }, h, m, false).show() }
            addView(time); addView(ampm); addView(tv("اضغط على الوقت لتغييره", 12f, GRAY)) }
        root.addView(timeBox, lp(M, W))
        root.addView(tv("المهام", 15f, GRAY).apply { gravity = Gravity.START }, lp(M, W).apply { bottomMargin = dp(8) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(CARD, 24) }
        missionList.forEachIndexed { i, mi ->
            list.addView(row(mi), lp(M, W))
            if (i < missionList.size - 1) list.addView(View(this).apply { setBackgroundColor(0x14FFFFFF) }, lp(M, 1).apply { marginStart = dp(76); marginEnd = dp(16) })
        }
        root.addView(list, lp(M, W))
        repsTv = tv("", 20f, Color.WHITE, true).apply { minWidth = dp(40) }
        fun step(s: String, d: Int) = tv(s, 22f, OR, true).apply { setPadding(dp(16), dp(2), dp(16), dp(2)); setOnClickListener { reps = (reps + d).coerceAtLeast(1); save() } }
        val pill = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = shape(0xFF22222C.toInt(), 30); addView(step("−", -1)); addView(repsTv); addView(step("+", 1)) }
        val repsRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(20), dp(4), dp(4))
            addView(tv("عدد التكرارات (ضغط / قرفصاء)", 14f).apply { gravity = Gravity.START }, lp(0, W, 1f)); addView(pill) }
        root.addView(repsRow, lp(M, W))
        toggle = tv("", 18f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, dp(18))
            setOnClickListener { if (Scheduler.enabled(this@MainActivity)) Scheduler.cancel(this@MainActivity) else { Scheduler.set(this@MainActivity, h, m, reps); Toast.makeText(this@MainActivity, "تم ضبط المنبه ✅", Toast.LENGTH_SHORT).show() }; refresh() } }
        root.addView(toggle, lp(M, W).apply { topMargin = dp(26) })
        root.addView(tv("جرّب المهام الآن", 15f, OR).apply { setPadding(0, dp(18), 0, dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, AlarmActivity::class.java).putExtra("reps", reps)) } }, lp(M, W))
        setContentView(ScrollView(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF1C1226.toInt(), 0xFF0B0B10.toInt())); layoutDirection = View.LAYOUT_DIRECTION_RTL; addView(root) })
        refresh()
    }
}
