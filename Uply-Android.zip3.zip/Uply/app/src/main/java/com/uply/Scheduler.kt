package com.uply
import android.app.*
import android.content.*
import java.util.Calendar

object Scheduler {
    private fun prefs(c: Context) = c.getSharedPreferences("uply", Context.MODE_PRIVATE)
    fun load(c: Context) = Triple(prefs(c).getInt("h", 6), prefs(c).getInt("m", 0), prefs(c).getInt("reps", 10))
    fun missions(c: Context) = prefs(c).getString("ms", "P")!!.split(",")
    fun setMissions(c: Context, l: List<String>) = prefs(c).edit().putString("ms", l.joinToString(",")).apply()
    fun enabled(c: Context) = prefs(c).getBoolean("on", false)
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 0,
        Intent(c, AlarmReceiver::class.java).putExtra("reps", load(c).third),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, h: Int, m: Int, reps: Int) {
        prefs(c).edit().putInt("h", h).putInt("m", m).putInt("reps", reps).putBoolean("on", true).apply()
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val p = pi(c)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(t.timeInMillis, p), p)
    }
    fun cancel(c: Context) { prefs(c).edit().putBoolean("on", false).apply(); c.getSystemService(AlarmManager::class.java).cancel(pi(c)) }
    fun reschedule(c: Context) { if (enabled(c)) load(c).let { set(c, it.first, it.second, it.third) } }
}
